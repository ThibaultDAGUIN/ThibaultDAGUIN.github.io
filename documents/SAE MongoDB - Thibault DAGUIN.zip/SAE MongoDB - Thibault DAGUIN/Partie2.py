import sqlite3
import pandas as pd
import pymongo

# Connexion à la base de données SQLite
conn = sqlite3.connect('covid.sqlite')

# Connexion à MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["covid_db5"]

try:
    # Migration des continents et des données pays dans la collection geo
    continents = pd.read_sql_query("SELECT * FROM continent", conn)
    pays_list = pd.read_sql_query("SELECT * FROM pays", conn)

    # Création d'un dictionnaire pour accéder rapidement aux informations des continents
    continents_dict = continents.set_index('code_continent').to_dict('index')

    # Ajout des informations de continent aux pays
    geo_data = []
    for _, pays in pays_list.iterrows():
        pays_data = pays.to_dict()
        code_continent = pays_data["code_continent"]
        if code_continent in continents_dict:
            pays_data["continent"] = continents_dict[code_continent]
        geo_data.append(pays_data)

    db.geo.insert_many(geo_data)
    print("Migration des données géographiques terminée")

    # Migration des statistiques dans la collection stats
    for _, pays in pays_list.iterrows():
        document_stats = {
            "code_iso": pays["code_iso"],
            "nom_pays": pays["nom_pays"]
        }

        # Récupération des cas
        cas = pd.read_sql_query("""
            SELECT date, nouveaux_cas, nouveaux_cas_lisses
            FROM cas
            WHERE code_iso = ?
            ORDER BY date
        """, conn, params=[pays["code_iso"]])
        document_stats["cas"] = cas.to_dict('records')

        # Récupération des décès
        deces = pd.read_sql_query("""
            SELECT date, nouveaux_morts, nouveaux_morts_lisses
            FROM deces
            WHERE code_iso = ?
            ORDER BY date
        """, conn, params=[pays["code_iso"]])
        document_stats["deces"] = deces.to_dict('records')

        # Récupération des hospitalisations
        hospitalisation = pd.read_sql_query("""
            SELECT date, patients_hospitalises
            FROM hospitalisation
            WHERE code_iso = ?
            ORDER BY date
        """, conn, params=[pays["code_iso"]])
        document_stats["hospitalisation"] = hospitalisation.to_dict('records')

        # Récupération des soins intensifs
        soin_intensif = pd.read_sql_query("""
            SELECT date, patients_en_soin_intensif
            FROM soin_intensif
            WHERE code_iso = ?
            ORDER BY date
        """, conn, params=[pays["code_iso"]])
        document_stats["soin_intensif"] = soin_intensif.to_dict('records')

        # Récupération des surmortalités
        surmortalite = pd.read_sql_query("""
            SELECT date, excess_mortality_cumulative_absolute, excess_mortality_cumulative, excess_mortality
            FROM surmortalite
            WHERE code_iso = ?
            ORDER BY date
        """, conn, params=[pays["code_iso"]])
        document_stats["surmortalite"] = surmortalite.to_dict('records')

        # Récupération des taux de reproduction
        taux_reproduction = pd.read_sql_query("""
            SELECT date, Taux_reproduction
            FROM taux_reproduction
            WHERE code_iso = ?
            ORDER BY date
        """, conn, params=[pays["code_iso"]])
        document_stats["taux_reproduction"] = taux_reproduction.to_dict('records')

        # Récupération des tests
        test = pd.read_sql_query("""
            SELECT date, nb_nouveaux_tests, nb_nouveaux_tests_lisses, Taux_positivite, tests_par_cas, unite_test
            FROM test
            WHERE code_iso = ?
            ORDER BY date
        """, conn, params=[pays["code_iso"]])
        document_stats["test"] = test.to_dict('records')

        # Récupération des vaccinations
        vaccination = pd.read_sql_query("""
            SELECT date, total_vaccinations, personnes_vaccinees, personnes_totalement_vaccinees, total_boosters, nouvelles_vaccinations, nouvelles_vaccinations_lisse, personnes_vaccinees_lisse
            FROM vaccination
            WHERE code_iso = ?
            ORDER BY date
        """, conn, params=[pays["code_iso"]])
        document_stats["vaccination"] = vaccination.to_dict('records')

        # Récupération des restrictions
        restriction = pd.read_sql_query("""
            SELECT date, stringency_index
            FROM restriction
            WHERE code_iso = ?
            ORDER BY date
        """, conn, params=[pays["code_iso"]])
        document_stats["restriction"] = restriction.to_dict('records')

        # Insertion du document dans la collection stats
        db.stats.insert_one(document_stats)

    print("Migration des statistiques terminée")

except Exception as e:
    print(f"Erreur pendant la migration: {str(e)}")
finally:
    # Fermeture des connexions
    conn.close()
    client.close()