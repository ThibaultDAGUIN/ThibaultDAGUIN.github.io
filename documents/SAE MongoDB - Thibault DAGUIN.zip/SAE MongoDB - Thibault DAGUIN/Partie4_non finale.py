import pymongo
import pandas as pd
import plotly.express as px
import dash
from dash import dcc, html
import dash_bootstrap_components as dbc

# Connexion à la base de données MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["covid_db5"]

def taux_infection():
    pipeline = [
        {
            "$lookup": {
                "from": "stats",
                "localField": "code_iso",
                "foreignField": "code_iso",
                "as": "stats"
            }
        },
        {
            "$unwind": "$stats"
        },
        {
            "$project": {
                "_id": 0,
                "nom_pays": 1,
                "total_cas": {"$sum": "$stats.cas.nouveaux_cas"},
                "population": 1
            }
        },
        {
            "$match": {
                "total_cas": {"$gt": 0}
            }
        },
        {
            "$project": {
                "nom_pays": 1,
                "total_cas": 1,
                "population": 1,
                "taux_infection": {
                    "$round": [
                        {"$multiply": [
                            {"$divide": ["$total_cas", "$population"]},
                            100
                        ]},
                        2
                    ]
                }
            }
        },
        {
            "$sort": {"taux_infection": -1}
        }
    ]
    result = list(db.geo.aggregate(pipeline))
    return pd.DataFrame(result)

def deces_par_continent():
    pipeline = [
        {
            "$lookup": {
                "from": "stats",
                "localField": "code_iso",
                "foreignField": "code_iso",
                "as": "stats"
            }
        },
        {
            "$unwind": "$stats"
        },
        {
            "$match": {
                "continent.nom_continent": {"$exists": True, "$ne": None}
            }
        },
        {
            "$project": {
                "continent": "$continent.nom_continent",
                "deces": {"$sum": "$stats.deces.nouveaux_morts"}
            }
        },
        {
            "$group": {
                "_id": "$continent",
                "total_morts": {"$sum": "$deces"}
            }
        },
        {
            "$project": {
                "_id": 0,
                "continent": "$_id",
                "total_morts": 1
            }
        },
        {
            "$sort": {"total_morts": -1}  # Tri descendant par total_morts
        }
    ]
    result = list(db.geo.aggregate(pipeline))
    return pd.DataFrame(result, columns=["continent", "total_morts"])


def create_dashboard():
    app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

    infection_df = taux_infection()
    deces_df = deces_par_continent()

    print(deces_df)
    
    # Carte des taux d'infection
    map_fig = px.choropleth(
        infection_df,
        locations="nom_pays",
        locationmode="country names",
        color="taux_infection",
        hover_name="nom_pays",
        color_continuous_scale="Reds",
        title="Taux d'infection par pays"
    )

    # Graphique des décès par continent
    bar_fig = px.bar(
        deces_df,
        x="continent",
        y="total_morts",
        title="Nombre de décès par continent",
        labels={"continent": "Continent", "total_morts": "Nombre de décès"},
        text_auto=True
    )

    app.layout = dbc.Container([
        dbc.Row([
            dbc.Col(dcc.Graph(figure=bar_fig), width=6),
            dbc.Col(dcc.Graph(figure=map_fig), width=6)
        ])
    ])

    return app

if __name__ == "__main__":
    app = create_dashboard()
    app.run_server(debug=True)
    client.close()