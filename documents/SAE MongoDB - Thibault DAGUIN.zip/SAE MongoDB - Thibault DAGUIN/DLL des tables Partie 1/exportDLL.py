import sqlite3

def get_table_ddl(cursor, table_name):
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = cursor.fetchall()
    
    ddl = f"CREATE TABLE {table_name} (\n"
    column_definitions = []
    for column in columns:
        col_name = column[1]
        col_type = column[2]
        not_null = "NOT NULL" if column[3] else ""
        default_value = f"DEFAULT {column[4]}" if column[4] is not None else ""
        primary_key = "PRIMARY KEY" if column[5] else ""
        
        column_definitions.append(f"    {col_name} {col_type} {not_null} {default_value} {primary_key}".strip())
    
    ddl += ",\n".join(column_definitions)
    ddl += "\n);"
    return ddl

def get_all_tables_ddl(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()
    
    ddl_statements = []
    for table in tables:
        table_name = table[0]
        ddl = get_table_ddl(cursor, table_name)
        ddl_statements.append(ddl)
    
    conn.close()
    return ddl_statements

# Chemin vers la base de données SQLite
db_path = 'covid.sqlite'

# Extraction des DDL
ddl_statements = get_all_tables_ddl(db_path)

# Affichage des DDL
for ddl in ddl_statements:
    print(ddl)
    print()