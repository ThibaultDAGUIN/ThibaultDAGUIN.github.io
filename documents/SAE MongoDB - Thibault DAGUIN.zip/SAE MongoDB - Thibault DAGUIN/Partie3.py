import pymongo
import pandas as pd
import sys

# sortie en UTF-8 avec sys
sys.stdout = open(1, 'w', encoding='utf-8', closefd=False)

# Connexion à MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["covid_db5"]

def nb_pays():
    return db.geo.count_documents({})

def probabilite_deces():
    pipeline = [
        {
            "$lookup": {
                "from": "stats",
                "localField": "code_iso",
                "foreignField": "code_iso",
                "as": "stats"
            }
        },
        {
            "$unwind": "$stats"
        },
        {
            "$project": {
                "_id": 0,
                "nom_pays": 1,
                "total_deces": {"$sum": "$stats.deces.nouveaux_morts"},
                "total_cas": {"$sum": "$stats.cas.nouveaux_cas"}
            }
        },
        {
            "$match": {
                "total_cas": {"$gt": 0},
                "total_deces": {"$gt": 0, "$exists": True, "$ne": None}
            }
        },
        {
            "$project": {
                "_id": 0,
                "nom_pays": 1,
                "total_deces": 1,
                "total_cas": 1,
                "probabilite_deces": {
                    "$multiply": [
                        {"$divide": ["$total_deces", "$total_cas"]},
                        100
                    ]
                }
            }
        },
        {
            "$sort": {"probabilite_deces": -1}
        }
    ]
    result = list(db.geo.aggregate(pipeline))
    return pd.DataFrame(result)

def taux_infection():
    pipeline = [
        {
            "$lookup": {
                "from": "stats",
                "localField": "code_iso",
                "foreignField": "code_iso",
                "as": "stats"
            }
        },
        {
            "$unwind": "$stats"
        },
        {
            "$project": {
                "_id": 0,
                "nom_pays": 1,
                "total_cas": {"$sum": "$stats.cas.nouveaux_cas"},
                "population": 1
            }
        },
        {
            "$match": {
                "total_cas": {"$gt": 0}  # S'assurer que total_cas est positif
            }
        },
        {
            "$project": {
                "nom_pays": 1,
                "total_cas": 1,
                "population": 1,
                "taux_infection": {
                    "$round": [
                        {"$multiply": [
                            {"$divide": ["$total_cas", "$population"]},
                            100
                        ]},
                        2  # Arrondir à 2 décimales
                    ]
                }
            }
        },
        {
            "$sort": {"taux_infection": -1}
        }
    ]
    result = list(db.geo.aggregate(pipeline))
    df = pd.DataFrame(result)
    # Réorganiser l'ordre des colonnes 
    df = df[["nom_pays", "total_cas", "population", "taux_infection"]]
    return df

def plus_fort_taux_infection_par_date():
    pipeline = [
        {
            "$lookup": {
                "from": "stats",
                "localField": "code_iso",
                "foreignField": "code_iso",
                "as": "stats"
            }
        },
        {
            "$unwind": "$stats"
        },
        {
            "$unwind": "$stats.cas"
        },
        {
            "$group": {
                "_id": {"date": "$stats.cas.date", "nom_pays": "$nom_pays", "population": "$population"},
                "total_cas": {"$sum": "$stats.cas.nouveaux_cas"}
            }
        },
        {
            "$project": {
                "date": "$_id.date",
                "nom_pays": "$_id.nom_pays",
                "taux_infection": {"$multiply": [{"$divide": ["$total_cas", "$_id.population"]}, 100]}
            }
        },
        {
            "$sort": {"date": 1, "taux_infection": -1}
        },
        {
            "$group": {
                "_id": "$date",
                "nom_pays": {"$first": "$nom_pays"},
                "taux_infection": {"$first": "$taux_infection"}
            }
        },
        {
            "$sort": {"_id": 1}
        }
    ]
    result = list(db.geo.aggregate(pipeline))
    return pd.DataFrame(result)



def taux_vaccination():
    pipeline = [
        {
            "$lookup": {
                "from": "stats",
                "localField": "code_iso",
                "foreignField": "code_iso",
                "as": "stats"
            }
        },
        {
            "$unwind": "$stats"
        },
        {
            "$unwind": "$stats.vaccination"
        },
        {
            "$match": {
                "stats.vaccination.personnes_totalement_vaccinees": {"$ne": ""}
            }
        },
        {
            "$group": {
                "_id": {
                    "nom_pays": "$nom_pays",
                    "population": "$population"
                },
                "max_vaccin_complet": {
                    "$max": {
                        "$toDouble": "$stats.vaccination.personnes_totalement_vaccinees"
                    }
                }
            }
        },
        {
            "$match": {
                "max_vaccin_complet": {"$gt": 0}
            }
        },
        {
            "$project": {
                "_id": 0,
                "nom_pays": "$_id.nom_pays",
                "population": "$_id.population",
                "taux_vaccination": {
                    "$round": [
                        {"$multiply": [
                            {"$divide": ["$max_vaccin_complet", "$_id.population"]},
                            100
                        ]},
                        2
                    ]
                }
            }
        },
        {
            "$sort": {"taux_vaccination": -1}
        }
    ]

    df = pd.DataFrame(list(db.geo.aggregate(pipeline)))
    return df[["nom_pays", "population", "taux_vaccination"]]

def mortalite_vaccination_par_continent():
    pipeline = [
        {
            "$lookup": {
                "from": "stats",
                "localField": "code_iso",
                "foreignField": "code_iso",
                "as": "stats"
            }
        },
        {
            "$unwind": "$stats"
        },
        {
            "$match": {
                "continent.nom_continent": {"$exists": True, "$ne": None}
            }
        },
        {
            "$group": {
                "_id": {
                    "pays_id": "$_id",
                    "continent": "$continent.nom_continent",
                    "population": "$population"
                },
                "max_vaccin": {
                    "$max": {
                        "$reduce": {
                            "input": "$stats.vaccination",
                            "initialValue": 0,
                            "in": {
                                "$cond": {
                                    "if": {
                                        "$and": [
                                            {"$ne": ["$$this.personnes_totalement_vaccinees", ""]},
                                            {"$gt": [{"$toDouble": "$$this.personnes_totalement_vaccinees"}, "$$value"]}
                                        ]
                                    },
                                    "then": {"$toDouble": "$$this.personnes_totalement_vaccinees"},
                                    "else": "$$value"
                                }
                            }
                        }
                    }
                },
                "max_surmortalite": {
                    "$max": {
                        "$ifNull": [
                            {
                                "$reduce": {
                                    "input": "$stats.surmortalite",
                                    "initialValue": 0,
                                    "in": {
                                        "$cond": {
                                            "if": {"$gt": ["$$this.excess_mortality_cumulative_absolute", "$$value"]},
                                            "then": "$$this.excess_mortality_cumulative_absolute",
                                            "else": "$$value"
                                        }
                                    }
                                }
                            },
                            0
                        ]
                    }
                }
            }
        },
        {
            "$group": {
                "_id": "$_id.continent",
                "surmortalite_moyenne": {"$avg": "$max_surmortalite"},
                "taux_vaccination_moyen": {
                    "$avg": {
                        "$cond": {
                            "if": {"$eq": ["$_id.population", 0]},
                            "then": 0,
                            "else": {
                                "$multiply": [
                                    {"$divide": ["$max_vaccin", "$_id.population"]},
                                    100
                                ]
                            }
                        }
                    }
                }
            }
        },
        {
            "$project": {
                "_id": 0,
                "nom_continent": "$_id",
                "surmortalite_moyenne": {"$round": ["$surmortalite_moyenne", 2]},
                "taux_vaccination_moyen": {"$round": ["$taux_vaccination_moyen", 2]}
            }
        },
        {
            "$sort": {"surmortalite_moyenne": -1}
        }
    ]
    
    return pd.DataFrame(list(db.geo.aggregate(pipeline)))

def top_10_pression_hospitaliere():
    pipeline = [
        {
            "$lookup": {
                "from": "stats",
                "localField": "code_iso",
                "foreignField": "code_iso",
                "as": "stats"
            }
        },
        {
            "$unwind": "$stats"
        },
        {
            "$project": {
                "_id": 0,
                "nom_pays": 1,
                "max_hospitalises": {
                    "$max": {
                        "$map": {
                            "input": "$stats.hospitalisation",
                            "in": "$$this.patients_hospitalises"
                        }
                    }
                },
                "max_soins_intensifs": {
                    "$max": {
                        "$map": {
                            "input": "$stats.soin_intensif",
                            "in": "$$this.patients_en_soin_intensif"
                        }
                    }
                }
            }
        },
        {
            "$match": {
                "max_soins_intensifs": {"$gt": 0},  # Doit avoir des soins intensifs
                "max_hospitalises": {"$gt": 0}  # Doit avoir des hospitalisations
            }
        },
        {
            "$sort": {"max_soins_intensifs": -1}
        },
        {
            "$limit": 10
        }
    ]
    
    return pd.DataFrame(list(db.geo.aggregate(pipeline)))

def pays_sans_deces():
    pipeline = [
        {
            "$lookup": {
                "from": "stats",
                "localField": "code_iso",
                "foreignField": "code_iso",
                "as": "stats"
            }
        },
        {
            "$unwind": "$stats"
        },
        {
            "$project": {
                "_id": 0,
                "nom_pays": 1,
                "total_cas": {"$sum": "$stats.cas.nouveaux_cas"},
                "total_deces": {"$sum": "$stats.deces.nouveaux_morts"}
            }
        },
        {
            "$match": {
                "total_cas": {"$gt": 0},
                "$or": [
                    {"total_deces": 0},
                    {"total_deces": None}
                ]
            }
        },
        {
            "$sort": {"total_cas": -1}
        }
    ]
    
    return pd.DataFrame(list(db.geo.aggregate(pipeline)))

def continents_faible_vaccination():
    pipeline = [
        {
            "$lookup": {
                "from": "stats",
                "localField": "code_iso",
                "foreignField": "code_iso",
                "as": "stats"
            }
        },
        {
            "$unwind": "$stats"
        },
        {
            "$match": {
                "continent.nom_continent": {"$ne": None}
            }
        },
        {
            "$project": {
                "nom_continent": "$continent.nom_continent",
                "nom_pays": 1,
                "max_vaccins": {
                    "$reduce": {
                        "input": "$stats.vaccination",
                        "initialValue": None,
                        "in": {
                            "$cond": [
                                {"$eq": ["$$this.total_vaccinations", ""]},
                                "$$value",
                                {
                                    "$cond": [
                                        {"$eq": ["$$value", None]},
                                        {"$toDouble": "$$this.total_vaccinations"},
                                        {
                                            "$cond": [
                                                {"$gt": [{"$toDouble": "$$this.total_vaccinations"}, "$$value"]},
                                                {"$toDouble": "$$this.total_vaccinations"},
                                                "$$value"
                                            ]
                                        }
                                    ]
                                }
                            ]
                        }
                    }
                },
                "population": 1
            }
        },
        {
            "$project": {
                "nom_continent": 1,
                "a_faible_vaccination": {
                    "$cond": [
                        {
                            "$or": [
                                {"$eq": ["$max_vaccins", None]},
                                {"$lt": [
                                    {
                                        "$multiply": [
                                            {"$divide": ["$max_vaccins", "$population"]},
                                            100
                                        ]
                                    },
                                    50
                                ]}
                            ]
                        },
                        1,
                        0
                    ]
                }
            }
        },
        {
            "$group": {
                "_id": "$nom_continent",
                "nombre_pays_sous_50_pourcent": {"$sum": "$a_faible_vaccination"}
            }
        },
        {
            "$project": {
                "_id": 0,
                "nom_continent": "$_id",
                "nombre_pays_sous_50_pourcent": 1
            }
        },
        {
            "$sort": {"nombre_pays_sous_50_pourcent": -1}
        }
    ]
    
    df = pd.DataFrame(list(db.geo.aggregate(pipeline)))
    # Réorganiser les colonnes
    return df[["nom_continent", "nombre_pays_sous_50_pourcent"]]


# ----- BONUS -----

def analyse_vagues():
    pipeline = [
        {
            "$lookup": {
                "from": "stats",
                "localField": "code_iso",
                "foreignField": "code_iso",
                "as": "stats"
            }
        },
        {
            "$unwind": "$stats"
        },
        {
            "$unwind": "$stats.cas"
        },
        {
            "$project": {
                "_id": 0,
                "nom_pays": 1,
                "population": {"$toDouble": "$population"},
                "nouveaux_cas": "$stats.cas.nouveaux_cas",
                "date": "$stats.cas.date",
                "periode": {
                    "$let": {
                        "vars": {
                            "year": {"$substr": [
                                "$stats.cas.date", 
                                {"$subtract": [{"$strLenCP": "$stats.cas.date"}, 4]}, 
                                4
                            ]},
                            "month": {
                                "$toInt": {
                                    "$substr": ["$stats.cas.date", 0, {
                                        "$subtract": [
                                            {"$indexOfCP": ["$stats.cas.date", "/"]},
                                            0
                                        ]
                                    }]
                                }
                            }
                        },
                        "in": {
                            "$switch": {
                                "branches": [
                                    {
                                        "case": {"$and": [
                                            {"$eq": ["$$year", "2020"]},
                                            {"$lte": ["$$month", 6]}
                                        ]},
                                        "then": "Vague_Initiale_2020"
                                    },
                                    {
                                        "case": {"$and": [
                                            {"$eq": ["$$year", "2020"]},
                                            {"$lte": ["$$month", 12]}
                                        ]},
                                        "then": "Vague_Fin_2020"
                                    },
                                    {
                                        "case": {"$and": [
                                            {"$eq": ["$$year", "2021"]},
                                            {"$lte": ["$$month", 6]}
                                        ]},
                                        "then": "Vague_Delta_2021"
                                    },
                                    {
                                        "case": {"$and": [
                                            {"$eq": ["$$year", "2021"]},
                                            {"$lte": ["$$month", 12]}
                                        ]},
                                        "then": "Vague_Omicron_2021"
                                    },
                                    {
                                        "case": {"$and": [
                                            {"$eq": ["$$year", "2022"]},
                                            {"$lte": ["$$month", 6]}
                                        ]},
                                        "then": "Vague_Début_2022"
                                    },
                                    {
                                        "case": {"$and": [
                                            {"$eq": ["$$year", "2022"]},
                                            {"$lte": ["$$month", 12]}
                                        ]},
                                        "then": "Vague_Fin_2022"
                                    },
                                    {
                                        "case": {"$eq": ["$$year", "2023"]},
                                        "then": "Phase_Endémique_2023"
                                    }
                                ],
                                "default": None
                            }
                        }
                    }
                }
            }
        },
        {
            "$match": {
                "periode": {"$ne": None}
            }
        },
        {
            "$group": {
                "_id": {
                    "nom_pays": "$nom_pays",
                    "periode": "$periode",
                    "population": "$population"
                },
                "total_cas": {"$sum": "$nouveaux_cas"}
            }
        },
        {
            "$project": {
                "_id": 0,
                "nom_pays": "$_id.nom_pays",
                "periode": "$_id.periode",
                "taux_infection": {
                    "$round": [
                        {
                            "$multiply": [
                                {"$divide": ["$total_cas", "$_id.population"]},
                                100
                            ]
                        },
                        2
                    ]
                }
            }
        },
        {
            "$sort": {"nom_pays": 1}
        }
    ]
    
    df = pd.DataFrame(list(db.geo.aggregate(pipeline)))
    
    ordre_periodes = {
        'Vague_Initiale_2020': 1,
        'Vague_Fin_2020': 2,
        'Vague_Delta_2021': 3,
        'Vague_Omicron_2021': 4,
        'Vague_Début_2022': 5,
        'Vague_Fin_2022': 6,
        'Phase_Endémique_2023': 7
    }
    
    df['ordre'] = df['periode'].map(ordre_periodes)
    df = df.sort_values(['nom_pays', 'ordre'])
    df = df.drop('ordre', axis=1)
    
    return df

def classification_impact_covid():
    pipeline = [
        {
            "$lookup": {
                "from": "stats",
                "localField": "code_iso",
                "foreignField": "code_iso",
                "as": "stats"
            }
        },
        {
            "$unwind": "$stats"
        },
        {
            "$project": {
                "_id": 0,
                "nom_pays": 1,
                "population": {"$toDouble": "$population"},
                "deces": {"$sum": "$stats.deces.nouveaux_morts"},
                "cas": {"$sum": "$stats.cas.nouveaux_cas"}
            }
        },
        {
            "$project": {
                "nom_pays": 1,
                "deces_par_100k": {
                    "$round": [
                        {"$multiply": [
                            {"$divide": ["$deces", "$population"]},
                            100000
                        ]},
                        2
                    ]
                },
                "taux_infection": {
                    "$round": [
                        {"$multiply": [
                            {"$divide": ["$cas", "$population"]},
                            100
                        ]},
                        2
                    ]
                }
            }
        },
                {
            "$match": {
                "deces_par_100k": {"$gt": 0}  # retirer les pays avec 0 décès par 100k
            }
        },
        {
            "$project": {
                "nom_pays": 1,
                "deces_par_100k": 1,
                "taux_infection": 1,
                "niveau_impact": {
                    "$switch": {
                        "branches": [
                            {
                                "case": {
                                    "$and": [
                                        {"$gt": ["$deces_par_100k", 200]},
                                        {"$gt": ["$taux_infection", 20]}
                                    ]
                                },
                                "then": "Impact Très Sévère"
                            },
                            {
                                "case": {
                                    "$and": [
                                        {"$gt": ["$deces_par_100k", 100]},
                                        {"$gt": ["$taux_infection", 10]}
                                    ]
                                },
                                "then": "Impact Sévère"
                            },
                            {
                                "case": {
                                    "$and": [
                                        {"$gt": ["$deces_par_100k", 50]},
                                        {"$gt": ["$taux_infection", 5]}
                                    ]
                                },
                                "then": "Impact Modéré"
                            }
                        ],
                        "default": "Impact Faible"
                    }
                }
            }
        },
        {
            "$sort": {"deces_par_100k": -1}
        },
        {
            "$group": {
                "_id": None,
                "pays": {"$push": "$$ROOT"}
            }
        },
        {
            "$unwind": {
                "path": "$pays",
                "includeArrayIndex": "index"
            }
        },
        {
            "$project": {
                "_id": 0,
                "nom_pays": "$pays.nom_pays",
                "deces_par_100k": "$pays.deces_par_100k",
                "taux_infection": "$pays.taux_infection",
                "niveau_impact": "$pays.niveau_impact",
                "rang_mondial": {"$add": ["$index", 1]}
            }
        },
        {
            "$sort": {"deces_par_100k": -1}
        }
    ]
    
    return pd.DataFrame(list(db.geo.aggregate(pipeline)))

def analyse_propagation_par_continent():
    """
    Analyse de la propagation des variants par continent
    """
    pipeline = [
        # Filtrer les documents avec continent non None
        {
            "$match": {
                "continent.nom_continent": {"$exists": True, "$ne": None}
            }
        },
        # Lookup pour joindre les stats de taux de reproduction
        {
            "$lookup": {
                "from": "stats",
                "localField": "code_iso",
                "foreignField": "code_iso",
                "as": "stats"
            }
        },
        # Déconstruire les stats
        {
            "$unwind": "$stats"
        },
        # Déconstruire les taux de reproduction
        {
            "$unwind": "$stats.taux_reproduction"
        },
        # Filtrer les taux de reproduction non nuls
        {
            "$match": {
                "stats.taux_reproduction.Taux_reproduction": {"$exists": True, "$ne": None, "$ne": ""}
            }
        },
        # Grouper par continent
        {
            "$group": {
                "_id": "$continent.nom_continent",
                "taux_reprod_moy": {
                    "$avg": {
                        "$toDouble": "$stats.taux_reproduction.Taux_reproduction"
                    }
                },
                "nb_pays": {"$addToSet": "$nom_pays"}
            }
        },
        # Projeter les résultats avec classification du risque
        {
            "$project": {
                "_id": 0,
                "nom_continent": "$_id",
                "taux_reprod_moy": {"$round": ["$taux_reprod_moy", 2]},
                "nb_pays": {"$size": "$nb_pays"},
                "risque_propagation": {
                    "$switch": {
                        "branches": [
                            {
                                "case": {"$gt": ["$taux_reprod_moy", 1.5]},
                                "then": "Très Élevé"
                            },
                            {
                                "case": {"$gt": ["$taux_reprod_moy", 1]},
                                "then": "Élevé"
                            },
                            {
                                "case": {"$gt": ["$taux_reprod_moy", 0.5]},
                                "then": "Modéré"
                            }
                        ],
                        "default": "Faible"
                    }
                }
            }
        },
        # Trier par taux de reproduction moyen
        {
            "$sort": {"taux_reprod_moy": -1}
        }
    ]
    
    return pd.DataFrame(list(db.geo.aggregate(pipeline)))

if __name__ == "__main__":
    print("\nNombre de pays:")
    print(nb_pays())
    
    print("\nProbabilité de décès par pays:")
    print(probabilite_deces())
    
    print("\nTaux d'infection par pays:")
    print(taux_infection())
    
    print("\nPlus fort taux d'infection par date:")
    print(plus_fort_taux_infection_par_date())
    
    print("\nTaux de vaccination par pays:")
    print(taux_vaccination())
    
    print("\nMortalité et vaccination par continent:")
    print(mortalite_vaccination_par_continent())
    
    print("\nTop 10 pression hospitalière:")
    print(top_10_pression_hospitaliere())
    
    print("\nPays sans décès:")
    print(pays_sans_deces())
    
    print("\nContinents avec faible taux de vaccination:")
    print(continents_faible_vaccination())
    
    # --- Bonus ---
    
    print("\nClassification de l'impact de la COVID:")
    print(classification_impact_covid())
    
    print("\nAnalyse de la propagation par continent:")
    print(analyse_propagation_par_continent())
    
    print("\nAnalyse des vagues:")
    print(analyse_vagues())
    
    client.close()