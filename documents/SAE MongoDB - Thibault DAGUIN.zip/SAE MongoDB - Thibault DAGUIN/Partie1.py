import sqlite3
import pandas as pd
import sys

if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

# Connexion à la base de données SQLite
conn = sqlite3.connect("covid.sqlite")

def nb_pays():
    return pd.read_sql_query("""
        SELECT COUNT(*) as total_pays
        FROM pays
    """, conn)

# a. Calculer la probabilité de décès par pays

def probabilite_deces():
    # Requête pour les décès
    deces = pd.read_sql_query("""
        SELECT 
            pays.nom_pays,
            SUM(deces.nouveaux_morts) as total_deces
        FROM deces 
        JOIN pays ON deces.code_iso = pays.code_iso
        GROUP BY pays.nom_pays
        ORDER BY total_deces DESC
    """, conn)

    # Requête pour les cas
    cas = pd.read_sql_query("""
        SELECT 
            pays.nom_pays,
            SUM(cas.nouveaux_cas) as total_cas
        FROM cas 
        JOIN pays ON cas.code_iso = pays.code_iso
        GROUP BY pays.nom_pays
        ORDER BY total_cas DESC
    """, conn)

    # Fusion des DataFrames
    df_analyse = pd.merge(deces, cas, on='nom_pays', how='inner')
    df_analyse['probabilite_deces'] = (df_analyse['total_deces'] / df_analyse['total_cas']) * 100
    df_analyse = df_analyse.sort_values(by='probabilite_deces', ascending=False)
    return df_analyse.reset_index(drop=True)

# b. Calculer le pourcentage de la population infectée par pays
def taux_infection():
    return pd.read_sql_query("""
        SELECT 
            pays.nom_pays,
            SUM(cas.nouveaux_cas) as total_cas,
            pays.population,
            ROUND(CAST(SUM(cas.nouveaux_cas) AS FLOAT) / population * 100, 2) as taux_infection
        FROM cas 
        JOIN pays ON cas.code_iso = pays.code_iso
        GROUP BY pays.nom_pays, pays.population
        HAVING taux_infection > 0
        ORDER BY taux_infection DESC
    """, conn)

# c. Identifier le pays avec le plus fort taux d'infection par date
def plus_fort_taux_infection_par_date():
    return pd.read_sql_query("""
        WITH TauxQuotidiens AS (
            SELECT 
                cas.date,
                pays.nom_pays,
                ROUND(CAST(SUM(cas.nouveaux_cas) AS FLOAT) / pays.population * 100, 4) as taux_infection,
                ROW_NUMBER() OVER (PARTITION BY cas.date 
                                ORDER BY CAST(SUM(cas.nouveaux_cas) AS FLOAT) / pays.population DESC) as rang
            FROM cas
            JOIN pays ON cas.code_iso = pays.code_iso
            GROUP BY cas.date, pays.nom_pays, pays.population
        )
        SELECT date, nom_pays, taux_infection
        FROM TauxQuotidiens
        WHERE rang = 1
        ORDER BY date
    """, conn)

# d. Calculer le taux de vaccination complet par pays
def taux_vaccination():
    return pd.read_sql_query("""
        SELECT 
            nom_pays AS Pays, 
            ROUND((MAX(CAST(personnes_totalement_vaccinees AS FLOAT)) * 100) / population, 2) AS Taux_de_vaccination, 
            Population
        FROM 
            pays, 
            vaccination 
        WHERE 
            pays.code_iso = vaccination.code_iso
        GROUP BY 
            nom_pays 
        ORDER BY 
            Taux_de_vaccination DESC;
    """, conn)

# e. Comparer surmortalité et vaccination par continent
def mortalite_vaccination_par_continent():
    return pd.read_sql_query("""
        WITH MaxParPays AS (
            SELECT 
                pays.code_continent,
                pays.code_iso,
                MAX(surmortalite.excess_mortality_cumulative_absolute) as max_surmortalite,
                MAX(CAST(vaccination.personnes_totalement_vaccinees AS FLOAT)) as personnes_vaccinees,
                pays.population
            FROM pays
            LEFT JOIN surmortalite ON pays.code_iso = surmortalite.code_iso
            LEFT JOIN vaccination ON pays.code_iso = vaccination.code_iso
            GROUP BY pays.code_continent, pays.code_iso, pays.population
        )
        SELECT 
            continent.nom_continent,
            ROUND(AVG(COALESCE(max_surmortalite, 0)), 2) as surmortalite_moyenne,
            ROUND(AVG(CASE 
                WHEN population > 0 AND personnes_vaccinees IS NOT NULL 
                THEN (personnes_vaccinees * 100.0 / population)
                ELSE 0 
            END), 2) as taux_vaccination_moyen
        FROM continent
        JOIN MaxParPays ON continent.code_continent = MaxParPays.code_continent
        GROUP BY continent.nom_continent
        ORDER BY surmortalite_moyenne DESC
    """, conn)

# f. Identifier le TOP 10 des pays avec la plus forte pression hospitalière
def top_10_pression_hospitaliere():
    return pd.read_sql_query("""
        SELECT 
            pays.nom_pays,
            MAX(hospitalisation.patients_hospitalises) as max_hospitalises,
            MAX(soin_intensif.patients_en_soin_intensif) as max_soins_intensifs
        FROM pays
        JOIN hospitalisation ON pays.code_iso = hospitalisation.code_iso
        LEFT JOIN soin_intensif ON pays.code_iso = soin_intensif.code_iso
        GROUP BY pays.nom_pays
        HAVING max_hospitalises > 0 OR max_soins_intensifs > 0
        ORDER BY max_soins_intensifs DESC
        LIMIT 10
    """, conn)

# g. Trouver les pays avec des cas mais sans décès

def pays_sans_deces():
    cas = pd.read_sql_query("""
        SELECT 
            pays.nom_pays,
            SUM(cas.nouveaux_cas) as total_cas
        FROM pays
        JOIN cas ON pays.code_iso = cas.code_iso
        GROUP BY pays.nom_pays
    """, conn)
    
    deces = pd.read_sql_query("""
        SELECT 
            pays.nom_pays,
            SUM(deces.nouveaux_morts) as total_deces
        FROM pays
        JOIN deces ON pays.code_iso = deces.code_iso
        GROUP BY pays.nom_pays
    """, conn)
    
    df_analyse = pd.merge(cas, deces, on='nom_pays', how='left')
    result = df_analyse[
        (df_analyse['total_cas'] > 0) & 
        (df_analyse['total_deces'].isna() | (df_analyse['total_deces'] == 0))
    ].sort_values('total_cas', ascending=False)
    
    # Remplacer les NaN par 0
    result = result.fillna(0).astype({'total_deces': int})
    
    # Réinitialiser l'index sans l'afficher
    result = result.reset_index(drop=True)
    
    return result

# h. Identifier les continents avec une faible couverture vaccinale

def continents_faible_vaccination():
    return pd.read_sql_query("""
        SELECT 
            continent.nom_continent,
            COUNT(pays.nom_pays) as nombre_pays_sous_50_pourcent
        FROM continent
        JOIN pays ON continent.code_continent = pays.code_continent
        LEFT JOIN (
            SELECT 
                code_iso,
                ROUND(MAX(CAST(total_vaccinations AS FLOAT)) * 100.0 / pays.population, 2) as taux
            FROM vaccination 
            JOIN pays USING(code_iso)
            GROUP BY code_iso, population
        ) v ON pays.code_iso = v.code_iso
        WHERE v.taux < 50 OR v.taux IS NULL
        GROUP BY continent.nom_continent
        ORDER BY nombre_pays_sous_50_pourcent DESC;
    """, conn)
    

# ------------- Requêtes annexes -------------------

# i. Analyser l'évolution mensuelle de la vaccination
def evolution_mensuelle_vaccination():
    """
    Analyse l'évolution de la vaccination par trimestre
    """
    return pd.read_sql_query("""
        WITH VaccinationTrimestre AS (
            SELECT 
                pays.nom_pays,
                strftime('%Y-Q%m', vaccination.date) as trimestre,
                MAX(vaccination.total_vaccinations) as vaccinations_fin_trimestre,
                pays.population
            FROM pays
            JOIN vaccination ON pays.code_iso = vaccination.code_iso
            GROUP BY pays.nom_pays, trimestre, pays.population
        )
        SELECT 
            nom_pays,
            trimestre,
            vaccinations_fin_trimestre,
            ROUND(CAST(vaccinations_fin_trimestre AS FLOAT) / population * 100, 2) as couverture_vaccinale,
            ROUND(((vaccinations_fin_trimestre - LAG(vaccinations_fin_trimestre, 1, 0) OVER (
                PARTITION BY nom_pays ORDER BY trimestre)) / 
                NULLIF(population, 0) * 100), 2) as progression_couverture
        FROM VaccinationTrimestre
        WHERE trimestre IS NOT NULL
        ORDER BY nom_pays, trimestre
    """, conn)



# j. Analyser la corrélation entre le taux de mortalité et la densité de population
def correlation_deces_densité():
    """
    Analyse la corrélation entre le taux de mortalité et la densité de population
    """
    return pd.read_sql_query("""
        WITH StatsPays AS (
            SELECT 
                pays.nom_pays,
                pays.population,
                pays.superficie,
                CAST(pays.population AS FLOAT) / NULLIF(pays.superficie, 0) as densite,
                SUM(deces.nouveaux_morts) as total_deces
            FROM pays
            JOIN deces ON pays.code_iso = deces.code_iso
            GROUP BY pays.nom_pays, pays.population, pays.superficie
            HAVING densite > 0
        ),
        StatsAvecQuartiles AS (
            SELECT 
                nom_pays,
                densite,
                ROUND(CAST(total_deces AS FLOAT) / population * 100000, 2) as deces_par_100k,
                NTILE(4) OVER (ORDER BY densite) as quartile_densite
            FROM StatsPays
        )
        SELECT 
            nom_pays,
            densite,
            deces_par_100k,
            quartile_densite,
            ROUND(AVG(deces_par_100k) OVER (PARTITION BY quartile_densite), 2) as moyenne_deces_quartile
        FROM StatsAvecQuartiles
        ORDER BY densite DESC
    """, conn)

    
# k. Analyser l'impact saisonnier sur les cas de COVID
def impact_saisonnier():
    """
    Analyse l'impact saisonnier sur les cas de COVID par saison
    """
    return pd.read_sql_query("""
        WITH CasSaisonniers AS (
            SELECT 
                pays.nom_pays,
                pays.code_continent,
                CASE 
                    WHEN strftime('%m', cas.date) IN ('12','01','02') THEN 'Hiver'
                    WHEN strftime('%m', cas.date) IN ('03','04','05') THEN 'Printemps'
                    WHEN strftime('%m', cas.date) IN ('06','07','08') THEN 'Été'
                    WHEN strftime('%m', cas.date) IN ('09','10','11') THEN 'Automne'
                END as saison,
                SUM(cas.nouveaux_cas) as total_cas,
                COUNT(DISTINCT strftime('%Y', cas.date)) as nombre_annees
            FROM pays
            JOIN cas ON pays.code_iso = cas.code_iso
            GROUP BY pays.nom_pays, pays.code_continent, saison
        )
        SELECT 
            continent.nom_continent,
            cs.saison,
            ROUND(AVG(cs.total_cas / cs.nombre_annees), 2) as moyenne_cas_par_saison
        FROM CasSaisonniers cs
        JOIN continent ON cs.code_continent = continent.code_continent
        WHERE cs.saison IS NOT NULL
        GROUP BY continent.nom_continent, cs.saison
        ORDER BY continent.nom_continent, 
            CASE cs.saison 
                WHEN 'Hiver' THEN 1 
                WHEN 'Printemps' THEN 2 
                WHEN 'Été' THEN 3 
                WHEN 'Automne' THEN 4 
            END
    """, conn)


# l. Analyse par vagues épidémiques
def efficacite_mesures_sanitaires():
    """
    Analyse l'efficacité des mesures sanitaires en comparant les périodes
    """
    return pd.read_sql_query("""
        WITH CasParPeriode AS (
            SELECT 
                pays.nom_pays,
                CASE 
                    WHEN strftime('%Y-%m', cas.date) <= '2020-06' THEN 'Première_Vague'
                    WHEN strftime('%Y-%m', cas.date) <= '2020-12' THEN 'Deuxième_Vague'
                    WHEN strftime('%Y-%m', cas.date) <= '2021-06' THEN 'Troisième_Vague'
                    ELSE 'Vagues_Suivantes'
                END as periode,
                SUM(cas.nouveaux_cas) as total_cas,
                pays.population
            FROM pays
            JOIN cas ON pays.code_iso = cas.code_iso
            GROUP BY pays.nom_pays, periode, pays.population
        )
        SELECT 
            nom_pays,
            periode,
            ROUND(CAST(total_cas AS FLOAT) / population * 100, 2) as taux_infection
        FROM CasParPeriode
        ORDER BY nom_pays, 
            CASE periode
                WHEN 'Première_Vague' THEN 1
                WHEN 'Deuxième_Vague' THEN 2
                WHEN 'Troisième_Vague' THEN 3
                WHEN 'Vagues_Suivantes' THEN 4
            END
    """, conn)


# m. Classer les pays selon l'impact global du COVID
def classification_impact_covid():
    """
    Classifie les pays selon l'impact global du COVID
    """
    return pd.read_sql_query("""
                WITH StatsCovid AS (
            SELECT 
                pays.nom_pays,
                pays.population,
                SUM(deces.nouveaux_morts) as total_deces,
                SUM(cas.nouveaux_cas) as total_cas
            FROM pays
            JOIN deces ON pays.code_iso = deces.code_iso
            JOIN cas ON pays.code_iso = cas.code_iso
            GROUP BY pays.nom_pays, pays.population
            HAVING total_cas > 0 AND total_deces > 0
        ),
        ImpactCovid AS (
            SELECT 
                nom_pays,
                ROUND(CAST(total_deces AS FLOAT) / population * 100000, 2) as deces_par_100k,
                ROUND(CAST(total_cas AS FLOAT) / population * 100, 2) as taux_infection
            FROM StatsCovid
        ),
        ClassificationPays AS (
            SELECT 
                nom_pays,
                deces_par_100k,
                taux_infection,
                CASE 
                    WHEN deces_par_100k > 200 AND taux_infection > 20 THEN 'Impact Très Sévère'
                    WHEN deces_par_100k > 100 AND taux_infection > 10 THEN 'Impact Sévère'
                    WHEN deces_par_100k > 50 AND taux_infection > 5 THEN 'Impact Modéré'
                    ELSE 'Impact Faible'
                END as niveau_impact
            FROM ImpactCovid
            WHERE deces_par_100k > 0
        )
        SELECT 
            cp.*,
            (SELECT COUNT(*) + 1 
            FROM ClassificationPays cp2 
            WHERE cp2.deces_par_100k > cp.deces_par_100k) as rang_mondial
        FROM ClassificationPays cp
        ORDER BY deces_par_100k DESC
    """, conn)
    



def analyse_propagation_par_continent():
    """
    Analyse de la propagation des variants par continent
    """
    return pd.read_sql_query("""
    WITH PropagationVariants AS (
        SELECT 
            continent.nom_continent,
            ROUND(AVG(taux_reproduction.Taux_reproduction), 2) as taux_reprod_moy,
            COUNT(DISTINCT pays.nom_pays) as nb_pays
        FROM continent
        JOIN pays ON continent.code_continent = pays.code_continent
        JOIN taux_reproduction ON pays.code_iso = taux_reproduction.code_iso
        WHERE taux_reproduction.Taux_reproduction IS NOT NULL
        GROUP BY continent.nom_continent
    )
    SELECT 
        nom_continent, 
        taux_reprod_moy, 
        nb_pays,
        CASE 
            WHEN taux_reprod_moy > 1.5 THEN 'Très Élevé'
            WHEN taux_reprod_moy > 1 THEN 'Élevé'
            WHEN taux_reprod_moy > 0.5 THEN 'Modéré'
            ELSE 'Faible'
        END as risque_propagation
    FROM PropagationVariants
    ORDER BY taux_reprod_moy DESC;
    """, conn)
    
def analyse_vagues():
        return pd.read_sql_query("""
            WITH CasParPeriode AS (
                SELECT 
                    pays.nom_pays,
                    CASE 
                        WHEN substr(cas.date, -4) = '2020' AND CAST(substr(cas.date, 1, instr(cas.date, '/') - 1) AS INTEGER) <= 6 THEN 'Vague_Initiale_2020'
                        WHEN substr(cas.date, -4) = '2020' AND CAST(substr(cas.date, 1, instr(cas.date, '/') - 1) AS INTEGER) <= 12 THEN 'Vague_Fin_2020'
                        WHEN substr(cas.date, -4) = '2021' AND CAST(substr(cas.date, 1, instr(cas.date, '/') - 1) AS INTEGER) <= 6 THEN 'Vague_Delta_2021'
                        WHEN substr(cas.date, -4) = '2021' AND CAST(substr(cas.date, 1, instr(cas.date, '/') - 1) AS INTEGER) <= 12 THEN 'Vague_Omicron_2021'
                        WHEN substr(cas.date, -4) = '2022' AND CAST(substr(cas.date, 1, instr(cas.date, '/') - 1) AS INTEGER) <= 6 THEN 'Vague_Début_2022'
                        WHEN substr(cas.date, -4) = '2022' AND CAST(substr(cas.date, 1, instr(cas.date, '/') - 1) AS INTEGER) <= 12 THEN 'Vague_Fin_2022'
                        WHEN substr(cas.date, -4) = '2023' THEN 'Phase_Endémique_2023'
                    END as periode,
                    SUM(cas.nouveaux_cas) as total_cas,
                    pays.population
                FROM pays
                JOIN cas ON pays.code_iso = cas.code_iso
                GROUP BY pays.nom_pays, periode, pays.population
            )
            SELECT 
                nom_pays,
                periode,
                ROUND(CAST(total_cas AS FLOAT) / population * 100, 2) as taux_infection
            FROM CasParPeriode
            WHERE periode IS NOT NULL
            ORDER BY nom_pays, 
                CASE periode
                    WHEN 'Vague_Initiale_2020' THEN 1
                    WHEN 'Vague_Fin_2020' THEN 2
                    WHEN 'Vague_Delta_2021' THEN 3
                    WHEN 'Vague_Omicron_2021' THEN 4
                    WHEN 'Vague_Début_2022' THEN 5
                    WHEN 'Vague_Fin_2022' THEN 6
                    WHEN 'Phase_Endémique_2023' THEN 7
                END;
                """
                , conn) 

if __name__ == "__main__":
    print("\nNombre de pays:")
    print(nb_pays())
    
    print("\nProbabilité de décès par pays:")
    print(probabilite_deces())
    
    print("\nTaux d'infection par pays:")
    print(taux_infection())
    
    print("\nPlus fort taux d'infection par date:")
    print(plus_fort_taux_infection_par_date())
    
    print("\nTaux de vaccination par pays:")
    print(taux_vaccination())
    
    print("\nMortalité et vaccination par continent:")
    print(mortalite_vaccination_par_continent())
    
    print("\nTop 10 pression hospitalière:")
    print(top_10_pression_hospitaliere())
    
    print("\nPays avec cas mais sans décès:")
    print(pays_sans_deces())
    
    print("\nContinents avec faible vaccination:")
    print(continents_faible_vaccination())
    

    # Requêtes annexes

    
    print("\nClassification de l'impact COVID:")
    print(classification_impact_covid())
    
    print("\nAnalyse de la propagation par Continent :")
    print(analyse_propagation_par_continent())
    
    print("\nAnalyse des vagues épidémiques:")
    print(analyse_vagues())
    

    
    conn.close()