SAÉ Migration de données vers un environnement NoSQL
Enseignant : François GARNIER
Etudiant : Thibault DAGUIN

Démarche :

Dans la séparation des données en collections j'ai d'abord analysé les DLL de la base relationnelle et divisé en 2 collections :
- geo : données pays / continents
- stats : données COVID

Suite à mon arrêt maladie (grippe) je n'ai malheureusement pas eu le temps de terminer ce travail, 
mon tableau de bord n'affiche que 2 indicateurs.

Je vous prie de bien vouloir m'en excuser.